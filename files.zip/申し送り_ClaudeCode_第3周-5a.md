# 申し送り（CEFRカタログ5 → Claude Code）── 第3周-5第一陣：検証済3行為の様式昇格

## 目的

第3周-5第一陣の成果一式（CEFRカタログ5でHideki承認済み）。13ファイル、+1235/-126行。
全数シート3枚を追加（授受31・会話維持5・感情8）し、全数シートは計8枚に。
梯子型別テンプレート（判断(u)）の初回適用試験を兼ね、合格。
判断(o)の適用条件を再精緻化（感情630の反例による）。

## 変更内容

1. **全数シート3枚（新設）**
   - `prototypes/catalog_infoexchange.json`（31行）＋ `infoexchange_full_prototype.py`
     ── 二相接続型テンプレート初回適用。検証範型③の情報管理相15行を継承し、
     質問応答相15行＋C1（No.489）の16行を新規作成（語彙チェッカー**ゼロフラグ**）。
     act_phases 全数一致を生成スクリプト内 assert に実装。継承 delta 2箇所
     （541・557）を統合後視点へ編集。
   - `prototypes/catalog_conversation.json`（5行）＋ `conversation_full_prototype.py`
     ── 管理梯子型。(o) 3値のうち「書面系列なし」の初適用。
   - `prototypes/catalog_emotion.json`（8行）＋ `emotion_full_prototype.py`
     ── 管理梯子型。第4段落に (o) 反例の記録（下記3）。
2. **`restore.py`** ── CATALOGS に3枚追加（授受31／会話維持5／感情8）
3. **判断(o)の再精緻化**（`data/cross_axes.json`・`data/ladder_templates.json`）
   ── 感情の Correspondence は B2（630）まで伸びるが中身は叙述解像度の最終段で
   制度化段ではない＝**B2到達は必要条件であって十分条件ではない**。条件を
   「**業務・公式の Correspondence 系列が B2 帯に達する行為で現れる**（私的系列の
   B2到達では行為自身の梯子が続く＝私的系列型）」へ更新。再現{632,633,628}と
   restore.py の assert は不変。※ladder_templates.json はこの更新時に indent=1 へ
   全体正規化（cross_axes 等と同形式。以後は安定）。差分が大きく見えるのはこのため。
4. **`tools/exponent_allowlist.txt`** ── keynote（未収録）1語追加。
   超過側の量産時裁定3語（pharmacy/workshop/plumber＝スロット名詞、(s)-1保持）と
   refreshed（保持）は各シート DISCUSSION 第5段落に保全。
5. **文書追随** ── 引き継ぎ書（§1現在地／§2判断(o)／§4第3周-5計画1✅）、
   README（現在地・ディレクトリ・復元検証値＝シート8枚）、**CLAUDE.md**（期待
   メッセージ行 ── 前回パッチの見落とし箇所。今回から追随対象として明記）。

## 適用手順

```bash
cd <ローカルリポジトリ>
git pull origin main
git apply --check cefr_round3-5a_three_sheets.patch
git apply cefr_round3-5a_three_sheets.patch
```

## 検証（スレッド側でクリーンcloneに対し自走確認済み）

```bash
# 再生成照合（生成スクリプト→JSONがバイト一致すること）
python3 prototypes/infoexchange_full_prototype.py
python3 prototypes/conversation_full_prototype.py
python3 prototypes/emotion_full_prototype.py
git status --porcelain | grep -v '^??' | wc -l   # 期待: 0（再生成による差分なし）
python3 restore.py
# 期待: 復元検証OK: … 全数シート意見31・苦情9・挨拶9・感謝詫び6・依頼6・授受31・会話維持5・感情8照合
python3 tools/exponent_level_check.py | tail -2
# 期待: 監査完了: 実例 473 文 ── レベル超過あり 32 文 / 未収録語あり 13 文（すべて裁定済みまたは既知）
```

検証が通ったら commit → push：

```bash
git add -A && git commit -m "第3周-5第一陣: 授受31・会話維持5・感情8の全数シート（テンプレート初回適用）＋判断(o)再精緻化（感情630の私的系列型反例）" && git push origin main
```

## 補足

- 新規6ファイルは `git apply` では**未追跡**として置かれるため、`git add -A` を忘れずに。
- Windows側のxlsxには影響なし（既存の未反映事項は§7のまま）。
- 次スレッド（CEFRカタログ6）は第3周-5第二陣：**明確化・繰り返しの要求17件**
  （二相接続型の三例目、「統合済・範型未検証」の解消）→ 仮判定13行為。
  判定案件：同意・不同意の昇格再判定／助言の帯の飛び／No.612採否（伝言の授受）。
